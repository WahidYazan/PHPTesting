<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['id_pembayaran'])) {
    header('Location: bayar.php');
    exit;
}

$id_pembayaran = $_POST['id_pembayaran'];

try {
    $stmt = $pdo->prepare(
        "UPDATE pembayaran SET status = 'lunas', waktu_bayar = NOW() WHERE id_pembayaran = ?"
    );
    $stmt->execute([$id_pembayaran]);
    header('Location: bayar.php');
    exit;
} catch (\PDOException $e) {
    header('Location: bayar.php?error=' . urlencode('Gagal update pembayaran: ' . $e->getMessage()));
    exit;
}
