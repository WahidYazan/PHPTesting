<?php require 'config.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pembayaran</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <span class="brand">🅿️ Sistem Parkir</span>
    <a href="index.php">Dashboard</a>
    <a href="tambah_transaksi.php">+ Kendaraan Masuk</a>
    <a href="checkout.php">Kendaraan Keluar</a>
    <a href="bayar.php" class="active">Pembayaran</a>
</div>

<div class="container">

<div class="section-title">Belum Bayar</div>
<table>
    <tr>
        <th>Plat Nomor</th>
        <th>Pemilik</th>
        <th>Waktu Masuk</th>
        <th>Waktu Keluar</th>
        <th>Biaya</th>
        <th>Aksi</th>
    </tr>
    <?php
    $sql = "SELECT pb.id_pembayaran, pb.jumlah_bayar, k.plat_nomor, p.nama,
                   t.waktu_masuk, t.waktu_keluar
            FROM pembayaran pb
            JOIN transaksi_parkir t ON t.id_transaksi = pb.id_transaksi
            JOIN kendaraan k ON k.id_kendaraan = t.id_kendaraan
            JOIN pemilik p ON p.id_pemilik = k.id_pemilik
            WHERE pb.status = 'belum'
            ORDER BY t.waktu_keluar";
    $belum = $pdo->query($sql)->fetchAll();
    if (count($belum) === 0): ?>
        <tr><td colspan="6" class="empty">Tidak ada tagihan yang belum dibayar</td></tr>
    <?php else:
        foreach ($belum as $b): ?>
        <tr>
            <td><?= htmlspecialchars($b['plat_nomor']) ?></td>
            <td><?= htmlspecialchars($b['nama']) ?></td>
            <td><?= htmlspecialchars($b['waktu_masuk']) ?></td>
            <td><?= htmlspecialchars($b['waktu_keluar']) ?></td>
            <td>Rp <?= number_format($b['jumlah_bayar'], 0, ',', '.') ?></td>
            <td>
                <form method="post" action="proses_bayar.php" style="display:inline;">
                    <input type="hidden" name="id_pembayaran" value="<?= $b['id_pembayaran'] ?>">
                    <button type="submit" class="btn small green">Tandai Lunas</button>
                </form>
            </td>
        </tr>
    <?php endforeach; endif; ?>
</table>

<div class="section-title">Riwayat Lunas</div>
<table>
    <tr>
        <th>Plat Nomor</th>
        <th>Pemilik</th>
        <th>Waktu Keluar</th>
        <th>Biaya</th>
        <th>Status</th>
    </tr>
    <?php
    $sql2 = "SELECT pb.jumlah_bayar, k.plat_nomor, p.nama, t.waktu_keluar
             FROM pembayaran pb
             JOIN transaksi_parkir t ON t.id_transaksi = pb.id_transaksi
             JOIN kendaraan k ON k.id_kendaraan = t.id_kendaraan
             JOIN pemilik p ON p.id_pemilik = k.id_pemilik
             WHERE pb.status = 'lunas'
             ORDER BY t.waktu_keluar DESC
             LIMIT 20";
    $lunas = $pdo->query($sql2)->fetchAll();
    if (count($lunas) === 0): ?>
        <tr><td colspan="5" class="empty">Belum ada riwayat pembayaran lunas</td></tr>
    <?php else:
        foreach ($lunas as $l): ?>
        <tr>
            <td><?= htmlspecialchars($l['plat_nomor']) ?></td>
            <td><?= htmlspecialchars($l['nama']) ?></td>
            <td><?= htmlspecialchars($l['waktu_keluar']) ?></td>
            <td>Rp <?= number_format($l['jumlah_bayar'], 0, ',', '.') ?></td>
            <td><span class="badge lunas">Lunas</span></td>
        </tr>
    <?php endforeach; endif; ?>
</table>

</div>
</body>
</html>
