<?php require 'config.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Kendaraan Masuk</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <span class="brand">🅿️ Sistem Parkir</span>
    <a href="index.php">Dashboard</a>
    <a href="tambah_transaksi.php" class="active">+ Kendaraan Masuk</a>
    <a href="checkout.php">Kendaraan Keluar</a>
    <a href="bayar.php">Pembayaran</a>
</div>

<div class="container">
<div class="section-title">Catat Kendaraan Masuk</div>

<?php if (isset($_GET['error'])): ?>
    <div class="alert error"><?= htmlspecialchars($_GET['error']) ?></div>
<?php endif; ?>

<form class="box" method="post" action="simpan_transaksi.php">

    <label>Kendaraan (Plat Nomor)</label>
    <select name="id_kendaraan" required>
        <option value="">-- Pilih Kendaraan --</option>
        <?php
        $sql = "SELECT k.id_kendaraan, k.plat_nomor, p.nama
                FROM kendaraan k JOIN pemilik p ON p.id_pemilik = k.id_pemilik
                ORDER BY k.plat_nomor";
        foreach ($pdo->query($sql) as $k): ?>
            <option value="<?= $k['id_kendaraan'] ?>">
                <?= htmlspecialchars($k['plat_nomor']) ?> - <?= htmlspecialchars($k['nama']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Slot Parkir Kosong</label>
    <select name="id_slot" required>
        <option value="">-- Pilih Slot --</option>
        <?php
        $sql = "SELECT id_slot, nomor_slot, lokasi FROM slot_parkir WHERE status = 'kosong' ORDER BY nomor_slot";
        $kosong = $pdo->query($sql)->fetchAll();
        if (count($kosong) === 0): ?>
            <option value="" disabled>Tidak ada slot kosong</option>
        <?php else:
            foreach ($kosong as $s): ?>
            <option value="<?= $s['id_slot'] ?>">
                <?= htmlspecialchars($s['nomor_slot']) ?> - <?= htmlspecialchars($s['lokasi']) ?>
            </option>
        <?php endforeach; endif; ?>
    </select>

    <p style="margin-top:14px;color:#6b7280;font-size:13px;">
        Waktu masuk akan otomatis dicatat sesuai waktu server saat form disimpan.
    </p>

    <div style="margin-top:20px;">
        <button type="submit" class="btn green">Simpan</button>
        <a href="index.php" class="btn" style="background:#9ca3af;">Batal</a>
    </div>
</form>

</div>
</body>
</html>
