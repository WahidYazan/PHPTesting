<?php require 'config.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Parkir</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <span class="brand">🅿️ Sistem Parkir</span>
    <a href="index.php" class="active">Dashboard</a>
    <a href="tambah_transaksi.php">+ Kendaraan Masuk</a>
    <a href="checkout.php">Kendaraan Keluar</a>
    <a href="bayar.php">Pembayaran</a>
</div>

<div class="container">

<?php
// Hitung status slot
$total  = $pdo->query("SELECT COUNT(*) FROM slot_parkir")->fetchColumn();
$terisi = $pdo->query("SELECT COUNT(*) FROM slot_parkir WHERE status = 'terisi'")->fetchColumn();
$kosong = $total - $terisi;
?>

<div class="cards">
    <div class="card total">
        <div class="num"><?= $total ?></div>
        <div class="label">Total Slot</div>
    </div>
    <div class="card terisi">
        <div class="num"><?= $terisi ?></div>
        <div class="label">Slot Terisi</div>
    </div>
    <div class="card kosong">
        <div class="num"><?= $kosong ?></div>
        <div class="label">Slot Kosong</div>
    </div>
</div>

<div class="section-title">Status Semua Slot</div>
<table>
    <tr>
        <th>Nomor Slot</th>
        <th>Lokasi</th>
        <th>Status</th>
    </tr>
    <?php
    $slots = $pdo->query("SELECT * FROM slot_parkir ORDER BY nomor_slot")->fetchAll();
    if (count($slots) === 0): ?>
        <tr><td colspan="3" class="empty">Belum ada data slot parkir</td></tr>
    <?php else:
        foreach ($slots as $s): ?>
        <tr>
            <td><?= htmlspecialchars($s['nomor_slot']) ?></td>
            <td><?= htmlspecialchars($s['lokasi']) ?></td>
            <td><span class="badge <?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span></td>
        </tr>
    <?php endforeach; endif; ?>
</table>

<div class="section-title">Kendaraan Sedang Parkir</div>
<table>
    <tr>
        <th>Plat Nomor</th>
        <th>Pemilik</th>
        <th>Jenis</th>
        <th>Lokasi / Slot</th>
        <th>Waktu Masuk</th>
    </tr>
    <?php
    $sql = "SELECT t.id_transaksi, k.plat_nomor, p.nama, j.nama_jenis,
                   sp.nomor_slot, sp.lokasi, t.waktu_masuk
            FROM transaksi_parkir t
            JOIN kendaraan k ON k.id_kendaraan = t.id_kendaraan
            JOIN pemilik p ON p.id_pemilik = k.id_pemilik
            JOIN jenis_kendaraan j ON j.id_jenis = k.id_jenis
            JOIN slot_parkir sp ON sp.id_slot = t.id_slot
            WHERE t.status = 'berlangsung'
            ORDER BY t.waktu_masuk DESC";
    $aktif = $pdo->query($sql)->fetchAll();
    if (count($aktif) === 0): ?>
        <tr><td colspan="5" class="empty">Tidak ada kendaraan yang sedang parkir</td></tr>
    <?php else:
        foreach ($aktif as $a): ?>
        <tr>
            <td><?= htmlspecialchars($a['plat_nomor']) ?></td>
            <td><?= htmlspecialchars($a['nama']) ?></td>
            <td><?= htmlspecialchars($a['nama_jenis']) ?></td>
            <td><?= htmlspecialchars($a['nomor_slot']) ?> - <?= htmlspecialchars($a['lokasi']) ?></td>
            <td><?= htmlspecialchars($a['waktu_masuk']) ?></td>
        </tr>
    <?php endforeach; endif; ?>
</table>

</div>
</body>
</html>
