# Sistem Parkir - Web App (PHP + MariaDB Servbay)

## Cara Menjalankan
1. Copy folder `parkir_app` ini ke folder web root Servbay Anda
   (biasanya sesuatu seperti `~/ServBay/www/` atau yang sudah Anda set di Servbay).
2. Buka `config.php`, pastikan host/port/user/password sudah sesuai
   (sudah diisi default: host `localhost`, port `3306`, user `root`, password `ServBay.dev`).
3. Buka browser ke `http://localhost/parkir_app/index.php`
   (sesuaikan domain/port sesuai konfigurasi Servbay Anda).

## PENTING: Sesuaikan dengan struktur tabel Anda
Aplikasi ini dibuat dengan ASUMSI struktur kolom berikut. Jika nama kolom
di database Anda berbeda, jalankan query ini di MariaDB:

```sql
SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = 'parkir'
ORDER BY TABLE_NAME, ORDINAL_POSITION;
```

Lalu kirim hasilnya, atau sesuaikan sendiri nama kolom di file-file berikut:

| File                     | Fungsi                                          |
|--------------------------|--------------------------------------------------|
| `index.php`              | Dashboard: jumlah slot, status, transaksi aktif  |
| `tambah_transaksi.php`   | Form catat kendaraan masuk                      |
| `simpan_transaksi.php`   | Proses simpan transaksi masuk                   |
| `checkout.php`           | Daftar kendaraan yang bisa diproses keluar      |
| `proses_keluar.php`      | Hitung biaya, catat waktu keluar                |
| `bayar.php`              | Daftar tagihan belum/sudah lunas                |
| `proses_bayar.php`       | Tandai pembayaran lunas                         |

### Struktur kolom yang diasumsikan:
- `slot_parkir`: id_slot, nomor_slot, lokasi, status ('kosong'/'terisi')
- `kendaraan`: id_kendaraan, plat_nomor, id_pemilik, id_jenis
- `pemilik`: id_pemilik, nama, no_hp
- `jenis_kendaraan`: id_jenis, nama_jenis
- `tarif`: id_tarif, id_jenis, tarif_awal, tarif_per_jam
- `transaksi_parkir`: id_transaksi, id_kendaraan, id_slot, waktu_masuk, waktu_keluar, biaya, status ('berlangsung'/'selesai')
- `pembayaran`: id_pembayaran, id_transaksi, jumlah_bayar, metode, waktu_bayar, status ('belum'/'lunas')

## Alur Pemakaian
1. **Dashboard** (`index.php`) — lihat jumlah slot kosong/terisi & kendaraan yang sedang parkir.
2. **+ Kendaraan Masuk** — pilih kendaraan terdaftar & slot kosong, waktu masuk otomatis dicatat.
3. **Kendaraan Keluar** — klik "Keluar Sekarang", sistem otomatis menghitung biaya
   berdasarkan tarif per jenis kendaraan dan durasi parkir, lalu slot kembali kosong.
4. **Pembayaran** — tandai tagihan sebagai lunas.

## Kemungkinan Penyesuaian
- Jika kolom tarif Anda hanya punya satu kolom biaya (bukan tarif_awal + tarif_per_jam),
  sederhanakan perhitungan di `proses_keluar.php`.
- Jika kendaraan baru perlu didaftarkan langsung dari form (bukan pilih dari yang sudah ada),
  saya bisa tambahkan form pendaftaran pemilik & kendaraan baru — tinggal minta.
