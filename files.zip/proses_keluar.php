<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['id_transaksi'])) {
    header('Location: checkout.php');
    exit;
}

$id_transaksi = $_POST['id_transaksi'];

try {
    $pdo->beginTransaction();

    // Ambil data transaksi + jenis kendaraan untuk cek tarif
    $sql = "SELECT t.id_slot, t.waktu_masuk, k.id_jenis
            FROM transaksi_parkir t
            JOIN kendaraan k ON k.id_kendaraan = t.id_kendaraan
            WHERE t.id_transaksi = ? AND t.status = 'berlangsung'
            FOR UPDATE";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id_transaksi]);
    $trx = $stmt->fetch();

    if (!$trx) {
        $pdo->rollBack();
        header('Location: checkout.php?error=' . urlencode('Transaksi tidak ditemukan atau sudah selesai'));
        exit;
    }

    // Ambil tarif sesuai jenis kendaraan
    $tarifStmt = $pdo->prepare("SELECT tarif_awal, tarif_per_jam FROM tarif WHERE id_jenis = ?");
    $tarifStmt->execute([$trx['id_jenis']]);
    $tarif = $tarifStmt->fetch();

    $tarif_awal    = $tarif['tarif_awal']    ?? 0;
    $tarif_per_jam = $tarif['tarif_per_jam'] ?? 0;

    // Hitung durasi (dibulatkan ke atas per jam, minimal 1 jam)
    $masuk  = new DateTime($trx['waktu_masuk']);
    $keluar = new DateTime(); // sekarang
    $selisih_menit = ($keluar->getTimestamp() - $masuk->getTimestamp()) / 60;
    $jam = max(1, (int) ceil($selisih_menit / 60));

    $biaya = $tarif_awal + ($jam > 1 ? ($jam - 1) * $tarif_per_jam : 0);
    // Jika tidak ada tarif_awal terpisah, gunakan perhitungan sederhana:
    if ($tarif_awal == 0) {
        $biaya = $jam * $tarif_per_jam;
    }

    // Update transaksi
    $update = $pdo->prepare(
        "UPDATE transaksi_parkir
         SET waktu_keluar = NOW(), biaya = ?, status = 'selesai'
         WHERE id_transaksi = ?"
    );
    $update->execute([$biaya, $id_transaksi]);

    // Bebaskan slot
    $updateSlot = $pdo->prepare("UPDATE slot_parkir SET status = 'kosong' WHERE id_slot = ?");
    $updateSlot->execute([$trx['id_slot']]);

    // Buat catatan pembayaran berstatus belum lunas
    $insertBayar = $pdo->prepare(
        "INSERT INTO pembayaran (id_transaksi, jumlah_bayar, status)
         VALUES (?, ?, 'belum')"
    );
    $insertBayar->execute([$id_transaksi, $biaya]);

    $pdo->commit();
    header('Location: bayar.php');
    exit;

} catch (\PDOException $e) {
    $pdo->rollBack();
    header('Location: checkout.php?error=' . urlencode('Gagal memproses: ' . $e->getMessage()));
    exit;
}
