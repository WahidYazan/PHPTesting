<?php require 'config.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kendaraan Keluar</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <span class="brand">🅿️ Sistem Parkir</span>
    <a href="index.php">Dashboard</a>
    <a href="tambah_transaksi.php">+ Kendaraan Masuk</a>
    <a href="checkout.php" class="active">Kendaraan Keluar</a>
    <a href="bayar.php">Pembayaran</a>
</div>

<div class="container">
<div class="section-title">Proses Kendaraan Keluar</div>

<table>
    <tr>
        <th>Plat Nomor</th>
        <th>Pemilik</th>
        <th>Jenis</th>
        <th>Slot</th>
        <th>Waktu Masuk</th>
        <th>Aksi</th>
    </tr>
    <?php
    $sql = "SELECT t.id_transaksi, k.plat_nomor, p.nama, j.nama_jenis,
                   sp.nomor_slot, t.waktu_masuk
            FROM transaksi_parkir t
            JOIN kendaraan k ON k.id_kendaraan = t.id_kendaraan
            JOIN pemilik p ON p.id_pemilik = k.id_pemilik
            JOIN jenis_kendaraan j ON j.id_jenis = k.id_jenis
            JOIN slot_parkir sp ON sp.id_slot = t.id_slot
            WHERE t.status = 'berlangsung'
            ORDER BY t.waktu_masuk";
    $data = $pdo->query($sql)->fetchAll();
    if (count($data) === 0): ?>
        <tr><td colspan="6" class="empty">Tidak ada kendaraan yang sedang parkir</td></tr>
    <?php else:
        foreach ($data as $d): ?>
        <tr>
            <td><?= htmlspecialchars($d['plat_nomor']) ?></td>
            <td><?= htmlspecialchars($d['nama']) ?></td>
            <td><?= htmlspecialchars($d['nama_jenis']) ?></td>
            <td><?= htmlspecialchars($d['nomor_slot']) ?></td>
            <td><?= htmlspecialchars($d['waktu_masuk']) ?></td>
            <td>
                <form method="post" action="proses_keluar.php" style="display:inline;">
                    <input type="hidden" name="id_transaksi" value="<?= $d['id_transaksi'] ?>">
                    <button type="submit" class="btn small red">Keluar Sekarang</button>
                </form>
            </td>
        </tr>
    <?php endforeach; endif; ?>
</table>

</div>
</body>
</html>
