<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tambah_transaksi.php');
    exit;
}

$id_kendaraan = $_POST['id_kendaraan'] ?? '';
$id_slot      = $_POST['id_slot'] ?? '';

if (!$id_kendaraan || !$id_slot) {
    header('Location: tambah_transaksi.php?error=' . urlencode('Kendaraan dan slot wajib dipilih'));
    exit;
}

try {
    $pdo->beginTransaction();

    // Pastikan slot masih kosong (hindari race condition)
    $cek = $pdo->prepare("SELECT status FROM slot_parkir WHERE id_slot = ? FOR UPDATE");
    $cek->execute([$id_slot]);
    $status = $cek->fetchColumn();

    if ($status !== 'kosong') {
        $pdo->rollBack();
        header('Location: tambah_transaksi.php?error=' . urlencode('Slot sudah terisi, silakan pilih slot lain'));
        exit;
    }

    $insert = $pdo->prepare(
        "INSERT INTO transaksi_parkir (id_kendaraan, id_slot, waktu_masuk, status)
         VALUES (?, ?, NOW(), 'berlangsung')"
    );
    $insert->execute([$id_kendaraan, $id_slot]);

    $update = $pdo->prepare("UPDATE slot_parkir SET status = 'terisi' WHERE id_slot = ?");
    $update->execute([$id_slot]);

    $pdo->commit();
    header('Location: index.php');
    exit;

} catch (\PDOException $e) {
    $pdo->rollBack();
    header('Location: tambah_transaksi.php?error=' . urlencode('Gagal menyimpan: ' . $e->getMessage()));
    exit;
}
